import { Component, Input } from '@angular/core';
import { NzModalService } from 'ng-zorro-antd/modal';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { TerritoryMaster } from 'src/app/Pages/Models/TerritoryMaster';
import { ApiServiceService } from 'src/app/Service/api-service.service';

@Component({
  selector: 'app-territory-pincode-mapping',
  templateUrl: './territory-pincode-mapping.component.html',
  styleUrls: ['./territory-pincode-mapping.component.css']
})
export class TerritoryPincodeMappingComponent {
  @Input() data: any =TerritoryMaster;
  @Input() drawerClose: any = Function;
  @Input() drawerVisible: boolean = false;


  PincodeMappingdata: any[] = [];
  searchText: string = '';
  isSpinning = false;
  // columns: string[][] = [['TRAINEE_NAME', 'TRAINEE_NAME']];



  allSelected = false;
  tableIndeterminate: boolean = false;

  constructor(
    private api: ApiServiceService,
    private message: NzNotificationService,
    private modal: NzModalService
  ) { }
  
  ngOnInit(){
this.getStateData()

  }
  
  // countryData: any = [];
  // getCountryData() {
  //   this.api.getAllCountryMaster(0, 0, '', '', 'AND IS_ACTIVE =1').subscribe(
  //     (data) => {
  //       if (data['code'] == 200) {
  //         this.countryData = data['data'];
  //       } else {
  //         this.countryData = [];
  //         this.message.error('Failed To Get Country Data', '');
  //       }
  //     },
  //     () => {
  //       this.message.error('Something Went Wrong', '');
  //     }
  //   );
  // }

  stateData: any = [];
  getStateData() {
    this.api.getState(0, 0, '', '', 'AND COUNTRY_ID='+this.data.COUNTRY_ID).subscribe(
      (data) => {
        if (data['code'] == 200) {
          this.stateData = data['data'];
        } else {
          this.stateData = [];
          this.message.error('Failed To Get State Data', '');
        }
      },
      () => {
        this.message.error('Something Went Wrong', '');
      }
    );
  }

  pincodeData: any = [];
  getPincodeData(stateId) {
    this.api.getAllPincode(0, 0, '', '', 'AND STATE_ID =' + stateId).subscribe(
      (data) => {
        if (data['code'] == 200) {
          this.pincodeData = data['data'];
        } else {
          this.pincodeData = [];
          this.message.error('Failed To Get Pincode Data', '');
        }
      },
      () => {
        this.message.error('Something Went Wrong', '');
      }
    );
  }


  PincodeMapping() {
    this.isSpinning = true;
    let likeQuery = '';

    // If searchText is provided, construct the likeQuery
    // if (this.searchText && this.searchText.trim() !== '') {
    //   likeQuery = ' AND';
    //   this.columns.forEach((column) => {
    //     likeQuery += ` ${column[0]} like '%${this.searchText}%' OR`;
    //   });
    //   likeQuery = likeQuery.substring(0, likeQuery.length - 2); // Remove the last 'OR'
    // }


    // Call the API with the constructed query
    this.api.getterritoryPincodeData(
      0,0,'','','',
      )
      .subscribe(
        (data) => {
          if (data['code'] === 200) {
            this.PincodeMappingdata = data['data'];
            // this.originalTraineeData = [...this.PincodeMappingdata];
            
          } else {
            this.PincodeMappingdata = [];
            this.message.error('Failed To Get Pincode Mapping Data...', '');
          }
          this.isSpinning = false;
        },
        () => {
          this.message.error('Something Went Wrong ...', '');
          this.isSpinning = false;
        }
      );
  }

  close() {
    this.drawerClose();
  }
  save() {
    this.isSpinning = true;



    // // Proceed with saving data if all entries are valid
    // const dataToSave = this.PincodeMappingdata.filter(
    //   (data) => data.STATUS === true || data.STATUS == '1'
    // ).map((data) => ({
    //   STATE_ID: data.STATE_ID,
    //  PINCODE_ID:data.PINCODE_ID,
 
    //   STATUS: data.STATUS
      
    // }));

    
  }

  Cancel(){}
  apply(){
   
     }
  add(): void {
    if (this.data.PINCODE==0 || this.data.PINCODE==undefined || this.data.PINCODE==null 
    && this.data.STATE_ID==0 || this.data.STATE_ID==undefined || this.data.STATE_ID==null ) {
      this.message.error('Please select State and Pincode.', '');
      return;
    }

    this.modal.confirm({
      nzTitle: 'Are you sure you want to add these Pincode details?',
      nzOkText: 'Yes',
      nzOkType: 'primary',
      nzOnOk: () => this.apply(),
      nzCancelText: 'No',
      nzOnCancel: () => this.Cancel(),
    });
  }


   // Function to toggle "Select All"
   toggleAll(checked: boolean): void {
    this.allSelected = checked;
  
    // Set all chapters to the same selected state
    // this.selectedChapters.forEach((chapter) => {
    //   chapter.selected = checked;
    // });
  
    // Reset the indeterminate state since all items are now either checked or unchecked
    this.tableIndeterminate = false;
  }
}
