import { DatePipe } from "@angular/common";
import { Component, Input } from "@angular/core";
import { NgForm } from "@angular/forms";
import { NzNotificationService } from "ng-zorro-antd/notification";
import { ApiServiceService } from "src/app/Service/api-service.service";
import { CommonFunctionService } from "src/app/Service/CommonFunctionService";
import { TechnicianMasterData } from "../../Models/TechnicianMasterData";

@Component({
  selector: "app-technician-masterdrawer",
  templateUrl: "./technician-masterdrawer.component.html",
  styleUrls: ["./technician-masterdrawer.component.css"],
})
export class TechnicianMasterdrawerComponent {
  employmentType: string = "O";
  @Input() data: any = TechnicianMasterData;
  @Input() drawerClose!: () => void;
  @Input() drawerVisible: boolean = false;
  selectedTab: number = 0;
  public commonFunction = new CommonFunctionService();
  constructor(
    private message: NzNotificationService,
    private api: ApiServiceService,
    private datePipe: DatePipe
  ) {}
  VehicleData = [
    { ID: 1, NAME: "Two-Wheeler" },
    { ID: 2, NAME: "Four-Wheeler" },
  ];
  ngOnInit() {
    // this.getallCities();
    // this, this.getallCountry();
    // this.getallStates();
    // this.getallPincodes();
  }
  Disabled = true;
  outertab = 0;
  onSelectedIndexChange(event: any) {
    this.outertab = event;
    if (event == 0) {
    }
  }
  isSpinning = false;
  isOk = true;
  passwordVisible: boolean = false;
  resetDrawer(VendorDrawer: NgForm) {
    this.data = new TechnicianMasterData();
    VendorDrawer.form.markAsPristine();
    VendorDrawer.form.markAsUntouched();
  }
  disableWeekEndDate = (current: Date): boolean => {
    if (this.data.WEEK_START_DATE) {
      const weekStartDate = new Date(this.data.WEEK_START_DATE);

      const startDateNormalized = new Date(
        weekStartDate.getFullYear(),
        weekStartDate.getMonth(),
        weekStartDate.getDate()
      );
      const currentDateNormalized = new Date(
        current.getFullYear(),
        current.getMonth(),
        current.getDate()
      );

      console.log("Current Date (Normalized):", currentDateNormalized);
      console.log("Week Start Date (Normalized):", startDateNormalized);
      console.log("Is Disabled:", currentDateNormalized < startDateNormalized);

      return currentDateNormalized < startDateNormalized;
    }
    return false;
  };
  save(addNew: boolean, VendorDrawer: NgForm): void {
    this.isSpinning = false;
    this.isOk = true;
    if (
      (this.data.BUSINESS_NAME.trim() == "" ||
        this.data.BUSINESS_NAME == null ||
        this.data.BUSINESS_NAME == undefined) &&
      (this.data.NAME.trim() == "" ||
        this.data.NAME == null ||
        this.data.NAME == undefined) &&
      (this.data.EMAIL_ID.trim() == "" ||
        this.data.EMAIL_ID == null ||
        this.data.EMAIL_ID == undefined) &&
      (this.data.MOBILE_NUMBER == undefined ||
        this.data.MOBILE_NUMBER == null ||
        this.data.MOBILE_NUMBER == 0) &&
      (this.data.GST_NO.trim() == "" ||
        this.data.GST_NO == null ||
        this.data.GST_NO == undefined) &&
      (this.data.PAN.trim() == "" ||
        this.data.PAN == null ||
        this.data.PAN == undefined) &&
      (this.data.ADDRESS1.trim() == "" ||
        this.data.ADDRESS1 == null ||
        this.data.ADDRESS1 == undefined) &&
      (this.data.COUNTRY_ID == undefined ||
        this.data.COUNTRY_ID == null ||
        this.data.COUNTRY_ID == 0) &&
      (this.data.STATE_ID.trim() == "" ||
        this.data.STATE_ID == null ||
        this.data.STATE_ID == undefined) &&
      (this.data.CITY_ID == undefined ||
        this.data.CITY_ID == null ||
        this.data.CITY_ID == 0) &&
      (this.data.PINCODE_ID == undefined ||
        this.data.PINCODE_ID == null ||
        this.data.PINCODE_ID == 0)
    ) {
      this.isOk = false;
      this.message.error("Please Fill All The Required Fields ", "");
    } else if (
      this.data.BUSINESS_NAME == null ||
      this.data.BUSINESS_NAME == undefined ||
      this.data.BUSINESS_NAME.trim() == ""
    ) {
      this.isOk = false;
      this.message.error(" Please Enter Business Name.", "");
    } else if (
      this.data.NAME == null ||
      this.data.NAME == undefined ||
      this.data.NAME.trim() == ""
    ) {
      this.isOk = false;
      this.message.error(" Please Enter Contact Person Name.", "");
    } else if (
      this.data.EMAIL_ID == null ||
      this.data.EMAIL_ID == undefined ||
      this.data.EMAIL_ID.trim() == ""
    ) {
      this.isOk = false;
      this.message.error(" Please Enter Email ID.", "");
    } else if (
      this.data.EMAIL_ID == null ||
      this.data.EMAIL_ID == undefined ||
      this.data.EMAIL_ID.trim() == ""
    ) {
      this.isOk = false;
      this.message.error(" Please Enter GST No.", "");
    } else if (
      this.data.GST_NO == null ||
      this.data.GST_NO == undefined ||
      this.data.GST_NO.trim() == ""
    ) {
      this.isOk = false;
      this.message.error(" Please Enter PAN.", "");
    } else if (
      this.data.PAN == null ||
      this.data.PAN == undefined ||
      this.data.PAN == 0
    ) {
      this.isOk = false;
      this.message.error("Please Enter Country Name.", "");
    } else if (
      this.data.STATE_ID == null ||
      this.data.STATE_ID == undefined ||
      this.data.STATE_ID == 0
    ) {
      this.isOk = false;
      this.message.error("Please Enter State Name.", "");
    } else if (
      this.data.CITY_ID == null ||
      this.data.CITY_ID == undefined ||
      this.data.CITY_ID == 0
    ) {
      this.isOk = false;
      this.message.error("Please Enter City Name.", "");
    } else if (
      this.data.MOBILE_NUMBER == null ||
      this.data.MOBILE_NUMBER == undefined ||
      this.data.MOBILE_NUMBER.trim() == ""
    ) {
      this.isOk = false;
      this.message.error(" Please Enter Mobile No.", "");
    } else if (
      this.data.PINCODE_ID == null ||
      this.data.PINCODE_ID == undefined ||
      this.data.PINCODE_ID.trim() == ""
    ) {
      this.isOk = false;
      this.message.error(" Please Enter Pincode.", "");
    }

    if (this.isOk) {
      this.isSpinning = true;
      {
        if (this.data.ID) {
          this.api.updateVendorData(this.data).subscribe((successCode: any) => {
            if (successCode.code == "200") {
              this.message.success("Vendor Data Updated Successfully", "");
              // if (!addNew) this.drawerClose();
              this.Disabled = false;
              this.selectedTab = 1;
              this.isSpinning = false;
            } else {
              this.message.error("Vendor Data Updation Failed", "");
              this.isSpinning = false;
            }
          });
        } else {
          this.api.createVendorData(this.data).subscribe((successCode: any) => {
            if (successCode.code == "200") {
              this.message.success("Vendor Data Created Successfully", "");
              if (!addNew) {
                this.drawerClose();
                this.Disabled = false;
                this.selectedTab = 1;
              } else {
                this.data = new TechnicianMasterData();
                this.resetDrawer(VendorDrawer);
                this.api.getVendorData(0, 0, "", "desc", "").subscribe(
                  (data) => {},
                  () => {}
                );
              }
              this.isSpinning = false;
            } else {
              this.message.error("Vendor Data Creation Failed...", "");
              this.isSpinning = false;
            }
          });
        }
      }
    }
  }
  close() {
    this.drawerClose();
  }

  CityData: any = [];
  getallCities() {
    this.api.getCityData(0, 0, "", "", "").subscribe(
      (data) => {
        if (data["code"] == 200) {
          this.CityData = data["data"];
        } else {
          this.CityData = [];
          this.message.error("Failed To Get City Data...", "");
        }
      },
      () => {
        this.message.error("Something Went Wrong ...", "");
      }
    );
  }
  PincodeData: any = [];
  getallPincodes() {
    this.api.getPincodeData(0, 0, "", "", "").subscribe(
      (data) => {
        if (data["code"] == 200) {
          this.PincodeData = data["data"];
        } else {
          this.PincodeData = [];
          this.message.error("Failed To Get City Data...", "");
        }
      },
      () => {
        this.message.error("Something Went Wrong ...", "");
      }
    );
  }
  StateData: any = [];
  getallStates() {
    this.api.getStateData(0, 0, "", "", "").subscribe(
      (data) => {
        if (data["code"] == 200) {
          this.StateData = data["data"];
        } else {
          this.StateData = [];
          this.message.error("Failed To Get State Data...", "");
        }
      },
      () => {
        this.message.error("Something Went Wrong ...", "");
      }
    );
  }
  CountryData: any = [];
  getallCountry() {
    this.api.getCountryData(0, 0, "", "", "").subscribe(
      (data) => {
        if (data["code"] == 200) {
          this.CountryData = data["data"];
        } else {
          this.CountryData = [];
          this.message.error("Failed To Get Country Data...", "");
        }
      },
      () => {
        this.message.error("Something Went Wrong ...", "");
      }
    );
  }
  StateData1: any = [];
  CityData1: any = [];
  PincodeData1: any = [];

  // Fetch states based on country ID
  getStatesByCountry(countryId: number) {
    this.api.getStateData(countryId, 0, "", "", "").subscribe(
      (data) => {
        if (data["code"] === 200) {
          this.StateData1 = data["data"];
        } else {
          this.StateData1 = [];
          this.message.error("Failed To Get State Data...", "");
        }
      },
      () => {
        this.message.error("Something Went Wrong...", "");
      }
    );
  }

  // Fetch cities based on state ID
  getCitiesByState(stateId: number) {
    this.api.getCityData(stateId, 0, "", "", "").subscribe(
      (data) => {
        if (data["code"] === 200) {
          this.CityData1 = data["data"];
        } else {
          this.CityData1 = [];
          this.message.error("Failed To Get City Data...", "");
        }
      },
      () => {
        this.message.error("Something Went Wrong...", "");
      }
    );
  }

  // Fetch pincodes based on city ID
  getPincodesByCity(cityId: number) {
    this.api.getPincodeData(cityId, 0, "", "", "").subscribe(
      (data) => {
        if (data["code"] === 200) {
          this.PincodeData1 = data["data"];
        } else {
          this.PincodeData1 = [];
          this.message.error("Failed To Get Pincode Data...", "");
        }
      },
      () => {
        this.message.error("Something Went Wrong...", "");
      }
    );
  }
}
